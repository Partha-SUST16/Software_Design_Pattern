/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Commad_Factory;

/**
 *
 * @author USER
 */
public class Fan {
//    boolean flag = false;
    void on()
    {
        System.out.println("Fan is on");
//        flag = true;
    }
    void off()
    {
        System.out.println("Fan is off");
//        flag = false;
    }
    
}
